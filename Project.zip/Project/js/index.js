import Navbar from "../components/navbar.js";
document.getElementById("navbar").innerHTML = Navbar()