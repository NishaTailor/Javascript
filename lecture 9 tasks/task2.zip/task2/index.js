// you have given a string

// input
// red and white
// output
// 4

let str="red and white"
let n = str.length
console.log(str.includes(""));
