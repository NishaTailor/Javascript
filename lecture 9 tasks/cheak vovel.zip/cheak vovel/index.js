let str="red";
let n=str.length;

for(let i=0;i<n;i++){
    if(str[i]=="a"|| str[i]=="e"||
        str[i]=="A"||str[i]=="E"){
            console.log("true");
        }
        else{
            console.log("false");
        }

}