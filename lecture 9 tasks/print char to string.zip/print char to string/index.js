let str = "rednwhite"

for (let i = 0; i < str.length; i++) {
    console.log(str[i]);
}